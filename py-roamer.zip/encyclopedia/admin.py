# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from encyclopedia.models import Species

# Register your models here.

admin.site.register(Species)
