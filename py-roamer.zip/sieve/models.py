# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# No distinct models for the sieve app - just use the Species from the encyclopedia app
from encyclopedia.models import Species
