# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class Species(models.Model):
    """ Class to represent a specific Lactarius mushroom

        Note: if adding more families, make this a superclass
        so that inheriting species can have different fields """
    scientific_name = models.CharField(max_length=20,
            verbose_name = "Scientific Name")
    cap_color = models.CharField(max_length=20,
            verbose_name = "Cap Color")
    cap_texture = models.CharField(max_length=20,
            verbose_name = "Cap Texture")
    cap_edge = models.CharField(max_length=20,
            verbose_name = "Cap Edge")
    gill_color = models.CharField(max_length=20,
            verbose_name = "Gill Color")
    latex_color = models.CharField(max_length=20,
            verbose_name = "Latex Color")
    latex_color_change = models.CharField(max_length=20,
            verbose_name = "Latex Color Change")
    flesh_color = models.CharField(max_length=20,
            verbose_name = "Flesh Color")
    flesh_changes_color = models.CharField(max_length=20,
            verbose_name = "Flesh Changes Color")
    zonal_cap = models.CharField(max_length=20,
            verbose_name = "Zonal Cap")
    taste = models.CharField(max_length=20,
            verbose_name = "Taste")
    odor = models.CharField(max_length=20,
            verbose_name = "Odor")
    stipe_color = models.CharField(max_length=20,
            verbose_name = "Stipe Color")
    stipe_texture = models.CharField(max_length=20,
            verbose_name = "Stipe Texture")
    spore_color = models.CharField(max_length=20,
            verbose_name = "Spore Color")

    def attrs(self):
        """ Generator for (field_name, data) pairs """
        for field in self._meta.fields:
            if field.name not in ["id", "scientific_name"]:
                yield field.verbose_name, getattr(self, field.name)

    @classmethod
    def get_fields(cls): 
        """ Generator for all Field objects in the class """   
        for field in cls._meta.fields:
            if field.name not in ["id", "scientific_name"]:
                yield field

    def __str__(self): 
        """ The string representation of the species is its scientific name """
        return self.scientific_name


